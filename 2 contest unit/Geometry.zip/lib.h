#include <iostream>
#include <vector>
#include <cmath>
namespace geometry {
class IShape;
class Point;
class Line;
class Ray;
class Segment;
class Polygon;
class Circle;

class Vector {
 private:
  int64_t x_ = 0;
  int64_t y_ = 0;

  friend class Point;
  friend class Line;
  friend class Ray;
  friend class Segment;
  friend class Polygon;
  friend class Circle;

  friend Vector operator+(const Vector&, const Vector&);
  friend Vector operator-(const Vector&, const Vector&);
  friend Vector operator-(const Point&, const Point&);
  friend Vector operator*(const Vector&, const int64_t&);
  friend Vector operator/(const Vector&, const int64_t&);
  friend bool operator==(const Vector&, const Vector&);

  friend double Length(const Vector&);
  friend double Sin(const Vector&, const Vector&);
  friend double Cos(const Vector&, const Vector&);
  friend int64_t VectorProduct(const Vector&, const Vector&);
  friend int64_t ScalarProduct(const Vector&, const Vector&);

 public:
  Vector() = default;
  Vector(const Point&, const Point&);
  Vector(const int64_t&, const int64_t&);
  Vector(const int64_t&, const int64_t&, const int64_t&, const int64_t&);

  Vector operator+() const;
  Vector operator-() const;
  Vector& operator+=(const Vector&);
  Vector& operator-=(const Vector&);
  Vector& operator*=(const int64_t&);
  Vector& operator/=(const int64_t&);

  ~Vector() = default;
};

class IShape {
 public:
  virtual IShape& Move(const Vector&) = 0;
  virtual bool ContainsPoint(const Point&) const = 0;
  virtual bool CrossesSegment(const Segment&) const = 0;
  virtual IShape* Clone() const = 0;
  virtual std::string ToString() const = 0;

  virtual ~IShape() = default;
};

class Point : public IShape {
  friend class Vector;
  friend class Segment;
  friend Vector operator-(const Point&, const Point&);

 public:
  int64_t x_ = 0;
  int64_t y_ = 0;

  Point() = default;
  Point(const int64_t&, const int64_t&);

  Point& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Point* Clone() const override;
  std::string ToString() const override;
};

class Segment : public IShape {
  friend class Point;
  friend class Line;
  friend class Ray;
  friend class Polygon;
  friend class Circle;

 private:
  Point begin_ = {0, 0};
  Point end_ = {0, 0};

 public:
  Segment() = default;
  Segment(const Point&, const Point&);
  Segment(const int64_t&, const int64_t&, const int64_t&, const int64_t&);

  Segment& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Segment* Clone() const override;
  std::string ToString() const override;

  double LengthSegment() const;
  bool IntersectSegment(const Point& begin_first, const Point& end_first, const Point& begin_second,
                        const Point& end_second) const;
  double Distance(const Point& point) const;
};

class Ray : public IShape {
  friend class Point;
  friend class Line;
  friend class Segment;
  friend class Polygon;
  friend class Circle;

 private:
  Point start_ = {0, 0};
  Vector vector_ = {0, 0};

 public:
  Ray() = default;
  Ray(const Point&, const Point&);
  Ray(const Vector&, const Point&);
  Ray(const int64_t&, const int64_t&, const int64_t&, const int64_t&);

  Ray& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Ray* Clone() const override;
  std::string ToString() const override;
};

class Line : public IShape {

  friend class Point;
  friend class Ray;
  friend class Segment;
  friend class Polygon;
  friend class Circle;

 private:
  Point point_ = {0, 0};
  Vector vector_ = {0, 0};

 public:
  Line() = default;
  Line(const Point&, const Point&);
  Line(const Vector&, const Point&);
  Line(const int64_t&, const int64_t&, const int64_t&);
  Line(const int64_t&, const int64_t&, const int64_t&, const int64_t&);

  double DistToPoint(const Point&) const;

  Line& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Line* Clone() const override;
  std::string ToString() const override;
};

class Polygon : public IShape {
  friend class Point;
  friend class Line;
  friend class Ray;
  friend class Segment;
  friend class Circle;

 private:
  std::vector<Point> n_points_;
  int size_ = n_points_.size();

 public:
  Polygon() = default;
  explicit Polygon(const std::vector<Point>&);

  Polygon& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Polygon* Clone() const override;
  std::string ToString() const override;
};

class Circle : public IShape {
  friend class Point;
  friend class Line;
  friend class Ray;
  friend class Segment;
  friend class Polygon;

 private:
  Point point_;
  double radius_ = 0;

 public:
  Circle() = default;
  Circle(const int64_t&, const int64_t&, const int64_t&);
  Circle(const Point&, const int64_t&);

  Circle& Move(const Vector&) override;
  bool ContainsPoint(const Point&) const override;
  bool CrossesSegment(const Segment&) const override;
  Circle* Clone() const override;
  std::string ToString() const override;
};
}  // namespace geometry
