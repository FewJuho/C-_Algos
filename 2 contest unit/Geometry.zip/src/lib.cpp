#include "../lib.h"
namespace geometry {

Vector operator+(const Vector& first, const Vector& second) {
  return Vector{first.x_ + second.x_, first.y_ + second.y_};
}

Vector operator-(const Point& first, const Point& second) {
  return Vector{first.x_ - second.x_, first.y_ - second.y_};
}

Vector operator-(const Vector& frst, const Vector& scnd) {
  return Vector{frst.x_ - scnd.x_, frst.y_ - scnd.y_};
}

Vector operator*(const Vector& first, const int64_t& a) {
  return Vector{first.x_ * a, first.y_ * a};
}

Vector operator/(const Vector& first, const int64_t& a) {
  return Vector{first.x_ / a, first.y_ / a};
}

bool operator==(const Vector& first, const Vector& second) {
  return first.x_ == second.x_ && first.y_ == second.y_;
}

double Length(const Vector& vector) {
  return sqrt(pow(vector.x_, 2) + pow(vector.y_, 2));
}

double Cos(const Vector& first, const Vector& second) {
  return ((ScalarProduct(first, second)) / (Length(first) * Length(second))) / 1.0;
}

int64_t ScalarProduct(const Vector& first, const Vector& second) {
  return first.x_ * second.x_ + first.y_ * second.y_;
}

int64_t VectorProduct(const Vector& first, const Vector& second) {
  return first.x_ * second.y_ - first.y_ * second.x_;
}

// vector (class) methods and operators
Vector::Vector(const Point& begin, const Point& end) : x_(end.x_ - begin.x_), y_(end.y_ - begin.y_) {
}

Vector::Vector(const int64_t& x, const int64_t& y) : x_(x), y_(y) {
}

Vector::Vector(const int64_t& start_x, const int64_t& start_y, const int64_t& end_x, const int64_t& end_y)
    : x_(end_x - start_x), y_(end_y - start_y) {
}

Vector Vector::operator+() const {
  return *this;
}

Vector Vector::operator-() const {
  return Vector(-x_, -y_);
}

Vector& Vector::operator+=(const Vector& inc_vector) {
  *this = *this + inc_vector;
  return *this;
}

Vector& Vector::operator-=(const Vector& dec_vector) {
  *this = *this - dec_vector;
  return *this;
}

Vector& Vector::operator*=(const int64_t& multiply) {
  *this = *this * multiply;
  return *this;
}

Vector& Vector::operator/=(const int64_t& multiply) {
  *this = *this / multiply;
  return *this;
}

// Point (class) methods
Point::Point(const int64_t& x, const int64_t& y) : x_(x), y_(y) {
}

Point& Point::Move(const Vector& vector) {
  this->x_ += vector.x_;
  this->y_ += vector.y_;
  return *this;
}

bool Point::ContainsPoint(const Point& point) const {
  return (x_ == point.x_) and (y_ == point.y_);
}

bool Point::CrossesSegment(const Segment& segment) const {
  return segment.ContainsPoint(*this);
}

Point* Point::Clone() const {
  return new Point(x_, y_);
}

std::string Point::ToString() const {
  std::string x_string = std::to_string(x_);
  std::string y_string = std::to_string(y_);
  return "Point(" + x_string + ", " + y_string + ")";
}

// Segment (class) methods
Segment::Segment(const Point& x, const Point& y) : begin_(x), end_(y) {
}

Segment::Segment(const int64_t& start_x, const int64_t& start_y, const int64_t& end_x, const int64_t& end_y)
    : begin_({start_x, start_y}), end_({end_x, end_y}) {
}

Segment& Segment::Move(const Vector& vect) {
  begin_.Move(vect);
  end_.Move(vect);
  return *this;
}

bool Segment::ContainsPoint(const Point& point) const {
  if (LengthSegment() == 0) {
    return point.ContainsPoint(end_);
  }
  Vector first{begin_, end_};
  Vector second{begin_, point};
  Vector third{end_, point};
  return Line{first, begin_}.ContainsPoint(point) && ScalarProduct(first, second) >= 0 &&
         ScalarProduct(-first, third) >= 0;
}

bool Segment::CrossesSegment(const Segment& segment) const {
  if (LengthSegment() != 0 && segment.LengthSegment() == 0) {
    return ContainsPoint(segment.begin_);
  } else if (LengthSegment() == 0 && segment.LengthSegment() == 0) {
    return segment.begin_.ContainsPoint(begin_);
  } else if (LengthSegment() == 0 && segment.LengthSegment() != 0) {
    return segment.ContainsPoint(begin_);
  }
  return IntersectSegment(begin_, end_, segment.begin_, segment.end_);
}

Segment* Segment::Clone() const {
  return new Segment(begin_, end_);
}

std::string Segment::ToString() const {
  auto str_begin_x = std::to_string(begin_.x_);
  auto str_begin_y = std::to_string(begin_.y_);
  auto str_end_x = std::to_string(end_.x_);
  auto str_end_y = std::to_string(end_.y_);
  return "Segment(Point(" + str_begin_x + ", " + str_begin_y + "), Point(" + str_end_x + ", " + str_end_y + "))";
}

double Segment::LengthSegment() const {
  return Length(Vector{begin_, end_});
}

bool Segment::IntersectSegment(const Point& begin_first, const Point& end_first, const Point& begin_second,
                               const Point& end_second) const {
  Vector vector_first{begin_first, end_first};
  Vector vector_second{begin_second, end_second};

  Segment segment_first{begin_first, end_first};
  Segment segment_second{begin_second, end_second};

  bool check1 = VectorProduct(vector_first, Vector{begin_first, begin_second}) *
                    VectorProduct(vector_first, Vector{begin_first, end_second}) <
                0;
  bool check2 = VectorProduct(vector_second, Vector{begin_second, begin_first}) *
                    VectorProduct(vector_second, Vector{begin_second, end_first}) <
                0;
  bool check3 = segment_first.ContainsPoint(begin_second) || segment_first.ContainsPoint(end_second) ||
                segment_second.ContainsPoint(begin_first) || segment_second.ContainsPoint(end_first);

  return (check1 && check2) || check3;
}

// Ray (class) methods

Ray::Ray(const Point& first, const Point& second) : start_(first), vector_({first.x_, first.y_, second.x_, second.y_}) {
}

Ray::Ray(const Vector& vector, const Point& start) : start_(start), vector_(vector) {
}

Ray::Ray(const int64_t& start_x, const int64_t& start_y, const int64_t& end_x, const int64_t& end_y)
    : start_({start_x, start_y}), vector_({start_x, start_y, end_x, end_y}) {
}

Ray& Ray::Move(const Vector& vect) {
  start_.Move(vect);
  return *this;
}

bool Ray::ContainsPoint(const Point& point) const {
  if (vector_.x_ == 0 && vector_.y_ == 0) {
    return point.ContainsPoint(start_);
  }
  return ScalarProduct(Vector{start_, point}, vector_) >= 0 && Line{vector_, start_}.ContainsPoint(point);
}
bool Ray::CrossesSegment(const Segment& segment) const {
  geometry::Line check_segment(vector_, start_);
  if (segment.LengthSegment() != 0) {
    if (start_.ContainsPoint(segment.begin_) or start_.ContainsPoint(segment.end_)) {
      return true;
    }
    if (!check_segment.CrossesSegment(segment)) {
      return false;
    }
    Vector first(start_, segment.begin_);
    Vector second(start_, segment.end_);
    auto Diff_Cos = Cos(first, vector_) - Cos(-second, vector_);
    return Diff_Cos >= 0;
  } else {
    return ContainsPoint(segment.begin_);
  }
}

Ray* Ray::Clone() const {
  return new Ray(vector_, start_);
}

std::string Ray::ToString() const {
  auto str_point_x = std::to_string(start_.x_);
  auto str_point_y = std::to_string(start_.y_);
  auto str_vector_x = std::to_string(vector_.x_);
  auto str_vector_y = std::to_string(vector_.y_);

  return "Ray(Point(" + str_point_x + ", " + str_point_y + "), Vector(" + str_vector_x + ", " + str_vector_y + "))";
}

// Line (class) methods
Line::Line(const Point& first, const Point& second)
    : point_(first), vector_({first.x_, first.y_, second.x_, second.y_}) {
}

Line::Line(const Vector& vector, const Point& point) : point_(point), vector_(vector) {
}

Line::Line(const int64_t& x_begin, const int64_t& y_begin, const int64_t& x_end, const int64_t& y_end)
    : point_({x_begin, y_begin}), vector_({x_begin, y_begin, x_end, y_end}) {
}

int64_t ExtGCD(int64_t a, int64_t b, int64_t& x, int64_t& y) {
  if (a == 0) {
    x = 0;
    y = 1;
    return b;
  }
  int64_t x1, y1;
  int64_t d = ExtGCD(b % a, a, x1, y1);
  x = y1 - (b / a) * x1;
  y = x1;
  return d;
}

Line::Line(const int64_t& a, const int64_t& b, const int64_t& c) {
  int64_t x, y;
  auto d = geometry::ExtGCD(a, b, x, y);
  point_ = {x * -c / d, y * -c / d};
  vector_ = {b, -a};
}

double Line::DistToPoint(const Point& point) const {
  Vector vector{point_, point};
  return std::abs(VectorProduct(vector, vector_)) / Length(vector_);
}

Line& Line::Move(const Vector& vector) {
  this->point_.Move(vector);
  return *this;
}

bool Line::ContainsPoint(const Point& point) const {
  return VectorProduct(Vector{point, point_}, vector_) == 0;
}

bool Line::CrossesSegment(const Segment& segment) const {
  if (segment.LengthSegment() == 0) {
    return ContainsPoint(segment.begin_);
  }
  Vector tmp1 = {point_, segment.begin_};
  Vector tmp2 = {point_, segment.end_};
  bool check1 = VectorProduct(tmp1, vector_) >= 0 && VectorProduct(tmp2, vector_) <= 0;
  bool check2 = VectorProduct(tmp2, vector_) >= 0 && VectorProduct(tmp1, vector_) <= 0;
  return (check1 or check2);
}

Line* Line::Clone() const {
  return new Line(vector_, point_);
}

std::string Line::ToString() const {
  auto a = std::to_string(vector_.y_);
  auto b = std::to_string(-vector_.x_);
  auto c = std::to_string((vector_.x_) * point_.y_ - (vector_.y_) * point_.x_);
  return "Line(" + a + ", " + b + ", " + c + ")";
}

Polygon::Polygon(const std::vector<Point>& nums) : n_points_(nums) {
}

Polygon& Polygon::Move(const Vector& vect) {
  for (auto i = 0; i < size_; i++) {
    n_points_[i].Move(vect);
  }
  return *this;
}

bool Polygon::ContainsPoint(const Point& point) const {
  auto x_max = n_points_[0].x_;
  auto count = 0;

  for (auto i = 0; i < size_; i++) {
    if (x_max <= n_points_[i].x_) {
      x_max = n_points_[i].x_;
    }
  }

  Segment segment_for_check{point.x_, point.y_, x_max + 1, point.y_ + 1};
  for (auto i = 0; i < size_ - 1; i++) {
    Segment segment{n_points_[i], n_points_[i + 1]};
    if (segment.CrossesSegment(segment_for_check)) {
      count++;
    }
    if (segment.ContainsPoint(point)) {
      return true;
    }
  }
  Segment segment{n_points_[size_ - 1], n_points_[0]};
  if (segment.CrossesSegment(segment_for_check)) {
    count++;
  }
  if (segment.ContainsPoint(point)) {
    return true;
  }
  return (count % 2 != 0);
}

bool Polygon::CrossesSegment(const Segment& segment) const {
  for (auto i = 0; i < size_ - 1; i++) {
    Segment sgmnt{n_points_[i], n_points_[i + 1]};
    if (segment.CrossesSegment(sgmnt)) {
      return true;
    }
  }
  Segment sgmnt{n_points_[size_ - 1], n_points_[0]};
  if (sgmnt.CrossesSegment(segment)) {
    return true;
  }
  return false;
}

Polygon* Polygon::Clone() const {
  return new Polygon(n_points_);
}

std::string Polygon::ToString() const {
  std::string str_result = "Polygon(";
  for (auto i = 0; i < size_; i++) {
    str_result += ("Point(" + std::to_string(n_points_[i].x_) + ", " + std::to_string(n_points_[i].y_) + ")");
    if (i == size_ - 1) {
      str_result += ")";
    } else {
      str_result += ", ";
    }
  }
  return str_result;
}

Circle::Circle(const int64_t& x, const int64_t& y, const int64_t& radius) : point_({x, y}), radius_(radius) {
}

Circle::Circle(const Point& point, const int64_t& radius) : point_(point), radius_(radius) {
}

Circle& Circle::Move(const Vector& vector) {
  point_.Move(vector);
  return *this;
}

bool Circle::ContainsPoint(const Point& point) const {
  auto distance = Length(Vector{point, point_});
  return distance <= radius_;
}

double Segment::Distance(const Point& point) const {
  Vector first_vector{begin_, end_};
  Vector second_vector{begin_, point};
  Vector third_vector{end_, point};
  if (ScalarProduct(first_vector, second_vector) >= 0 && ScalarProduct(-first_vector, third_vector) >= 0) {
    return Line{begin_, end_}.DistToPoint(point);
  }
  return std::min(Length(second_vector), Length(third_vector));
}

bool Circle::CrossesSegment(const Segment& segment) const {
  if (segment.LengthSegment() == 0) {
    return ContainsPoint(segment.begin_);
  } else if (radius_ == 0) {
    return segment.ContainsPoint(point_);
  }
  Vector first{point_, segment.begin_};
  Vector second{point_, segment.end_};
  return segment.Distance(point_) <= radius_ && (Length(first) >= radius_ || Length(second) >= radius_);
}

Circle* Circle::Clone() const {
  return new Circle(point_, radius_);
}

std::string Circle::ToString() const {
  return "Circle(Point(" + std::to_string(point_.x_) + ", " + std::to_string(point_.y_) + "), " +
         std::to_string(static_cast<int>(radius_)) + ")";
}
}  // namespace geometry